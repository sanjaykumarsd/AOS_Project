package cgol;

public interface BoardListener {
	
	public void updated(BoardModel m);
	
}
